

package juego;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

public class CJuego implements ActionListener{

    private VJuego vista;
    private int var;


    public CJuego(VJuego v){
        vista=v;
        var=0;
    }
    
    public void actionPerformed(ActionEvent e) {
       System.out.println("entro");
        System.out.println("var = " + var);
        System.out.println("e.getSource() = " + ((JButton)e.getSource()).getName());
        if(var == 0){
        if ((((JButton)e.getSource()).getName()) == "b11"){
            vista.setEtiqueta1("X");
            var=1;
        }else if((((JButton)e.getSource()).getName()) == "b12"){
            vista.setEtiqueta2("X");
             var=1;
        }else if((((JButton)e.getSource()).getName()) == "b13"){
            vista.setEtiqueta3("X");
             var=1;
        }
        else if((((JButton)e.getSource()).getName()) == "b21"){
            vista.setEtiqueta4("X");
             var=1;    
        }
        else if((((JButton)e.getSource()).getName()) == "b22"){
            vista.setEtiqueta5("X");
             var=1;
        }
        else if((((JButton)e.getSource()).getName()) == "b23"){
            vista.setEtiqueta6("X");
             var=1;
        }
        else if((((JButton)e.getSource()).getName()) == "b31"){
            vista.setEtiqueta7("X");
             var=1;
        }
        else if((((JButton)e.getSource()).getName()) == "b32"){
            vista.setEtiqueta8("X");
             var=1;
        }
        else if((((JButton)e.getSource()).getName()) == "b33"){
            vista.setEtiqueta9("X");
             var=1;
        }
     }else{
            if((((JButton)e.getSource()).getName()) == "b11"){
            vista.setEtiqueta1("O");
            var=0;
        }else if((((JButton)e.getSource()).getName()) == "b12"){
            vista.setEtiqueta2("O");
             var=0;
        }else if((((JButton)e.getSource()).getName()) == "b13"){
            vista.setEtiqueta3("O");
             var=0;
        }
        else if((((JButton)e.getSource()).getName()) == "b21"){
            vista.setEtiqueta4("O");
             var=0;    
        }
        else if((((JButton)e.getSource()).getName()) == "b22"){
            vista.setEtiqueta5("O");
             var=0;
        }
        else if((((JButton)e.getSource()).getName()) == "b23"){
            vista.setEtiqueta6("O");
             var=0;
        }
        else if((((JButton)e.getSource()).getName()) == "b31"){
            vista.setEtiqueta7("O");
             var=0;
        }
        else if((((JButton)e.getSource()).getName()) == "b32"){
            vista.setEtiqueta8("O");
             var=0;
        }
        else if((((JButton)e.getSource()).getName()) == "b33"){
            vista.setEtiqueta9("O");
             var=0;
        }
         
        }
    }
}
