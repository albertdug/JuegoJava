

package juego;

import java.awt.Color;
import javax.swing.JFrame;



public class Main {

    public static void main(String[] args) {
    JFrame v= new VJuego();
     v.pack();
     v.setSize(300,300);
     v.setVisible(true);


    }



}
