
package juego;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class VJuego extends JFrame {

    private JPanel ptitulo, pcontenido;
    private JButton b11, b12, b13, b21, b22, b23, b31, b32, b33;
    private JLabel etitulo;
    private CJuego control;

    public VJuego(){
        control = new CJuego(this);
        ptitulo= new JPanel();
        etitulo= new JLabel("LA VIEJA");
        ptitulo.add(etitulo);

        pcontenido= new JPanel();
        pcontenido.setLayout(new GridLayout(3,3));

        b11= new JButton();
        b11.setBackground(Color.pink);
        b11.addActionListener(control);
        b11.setName("b11");

        b12= new JButton();
        b12.setBackground(Color.pink);
        b12.addActionListener(control);
        b12.setName("b12");

        b13= new JButton();
        b13.setBackground(Color.pink);
        b13.addActionListener(control);
        b13.setName("b13");

        b21= new JButton();
        b21.setBackground(Color.pink);
        b21.addActionListener(control);
        b21.setName("b21");

        b22= new JButton();
        b22.setBackground(Color.pink);
        b22.addActionListener(control);
        b22.setName("b22");

        b23= new JButton();
        b23.setBackground(Color.pink);
        b23.addActionListener(control);
        b23.setName("b23");

        b31= new JButton();
        b31.setBackground(Color.pink);
        b31.addActionListener(control);
        b31.setName("b31");

        b32= new JButton();
        b32.setBackground(Color.pink);
        b32.addActionListener(control);
        b32.setName("b32");

        b33= new JButton();
        b33.setBackground(Color.pink);
        b33.addActionListener(control);
        b33.setName("b33");

        pcontenido.add(b11);
        pcontenido.add(b12);
        pcontenido.add(b13);
        pcontenido.add(b21);
        pcontenido.add(b22);
        pcontenido.add(b23);
        pcontenido.add(b31);
        pcontenido.add(b32);
        pcontenido.add(b33);

        add(ptitulo, BorderLayout.NORTH);
        add(pcontenido);



        
        }

public void setEtiqueta1(String letra){
    this.b11.setText(letra);
    this.b11.setEnabled(false);
}

public void setEtiqueta2(String letra){
    this.b12.setText(letra);
    this.b12.setEnabled(false);

}

public void setEtiqueta3(String letra){
    this.b13.setText(letra);
    this.b13.setEnabled(false);
}

public void setEtiqueta4(String letra){
    this.b21.setText(letra);
    this.b21.setEnabled(false);

}

public void setEtiqueta5(String letra){
    this.b22.setText(letra);
    this.b22.setEnabled(false);
}

public void setEtiqueta6(String letra){
    this.b23.setText(letra);
    this.b23.setEnabled(false);
}

public void setEtiqueta7(String letra){
    this.b31.setText(letra);
    this.b31.setEnabled(false);
}


public void setEtiqueta8(String letra){
    this.b32.setText(letra);
    this.b32.setEnabled(false);
}

public void setEtiqueta9(String letra){
    this.b33.setText(letra);
    this.b33.setEnabled(false);
}




}
